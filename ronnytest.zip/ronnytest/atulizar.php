<?php
$dados = file_get_contents("https://swapi.co/api/people/?format=json");
$personagens = json_decode($dados, true);


 for ($i=0; $i < 10; $i++) { 
		
?>	
			 
			<tr>
			
			  <td><?php echo $personagens['results'][$i]['name'];?></td>	
			  <td><?php echo $personagens['results'][$i]['mass'];?></td>
			  <td><?php echo $personagens['results'][$i]['hair_color'];?></td>
			  <td><?php echo $personagens['results'][$i]['eye_color'];?></td>
			  <td><?php echo $personagens['results'][$i]['gender'];?></td>
			</tr>
<?php 
		
	} 

?>