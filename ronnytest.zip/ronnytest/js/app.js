var formu = document.forms.pesquisa;
var campo = document.getElementById("nome");
var conteudo = document.getElementById("psq");
campo.onkeyup= function () {
  requisitarArquivo("psq.php?nome="+campo.value,conteudo);
}
formu.onsubmit = function(e){
e.preventDefault();
}
var btn = document.getElementById("btn1");
btn.onclick = function(){
	requisitarArquivo("atulizar.php",conteudo);
}